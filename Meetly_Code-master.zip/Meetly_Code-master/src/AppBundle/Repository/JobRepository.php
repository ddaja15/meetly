<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/8/2018
 * Time: 8:49 PM
 */

namespace AppBundle\Repository;


class JobRepository
{

}