<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 3/8/2018
 * Time: 6:21 PM
 */

namespace AppBundle\Repository;


class UserRepository
{

}